# Personal Expense Tracker (MongoDB CRUD Project)

A beginner-friendly full-stack web application for recording income and expenses, viewing monthly totals, and managing category budgets. It uses Node.js, Express, MongoDB, Mongoose, HTML, CSS and vanilla JavaScript.

## Features
- Create, read, update and delete income/expense transactions (CRUD).
- Search and filter transactions by type, category, and month.
- Monthly income, expense, balance and transaction-count summary.
- Create, view, update and delete monthly category budgets.
- Budget progress and remaining/over-budget amount.
- Server-side validation using Mongoose schemas.
- Responsive interface for computer and mobile screens.

## Requirements
- Node.js 18 or newer
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- Internet is not required for the app interface after Node dependencies are installed.

## Setup on Windows
1. Install Node.js from https://nodejs.org/ and install MongoDB Community Server, or create a MongoDB Atlas cluster.
2. Extract this project ZIP to a folder such as `C:\Projects\personal_expense_tracker`.
3. Open that folder in Command Prompt or the terminal in VS Code.
4. Install packages:
   ```bash
   npm install
   ```
5. Copy `.env.example` and rename the copy to `.env`.
6. Open `.env`. For local MongoDB use:
   ```env
   PORT=3000
   MONGODB_URI=mongodb://127.0.0.1:27017/expense_tracker_db
   ```
   For MongoDB Atlas, replace the URI with your own Atlas connection string. Do not share your real connection string or password.
7. Make sure the MongoDB service is running.
8. Start the app:
   ```bash
   npm start
   ```
9. Open `http://localhost:3000` in a browser.

The database `expense_tracker_db` and its collections are created automatically when the app first saves records. Collections are `transactions` and `budgets`.

## API endpoints

### Transactions
- `GET /api/transactions` — list all transactions; optional query parameters: `type`, `category`, `month=YYYY-MM`.
- `POST /api/transactions` — create a transaction.
- `PUT /api/transactions/:id` — update a transaction.
- `DELETE /api/transactions/:id` — delete a transaction.

Example JSON for `POST /api/transactions`:
```json
{
  "title": "Transport to campus",
  "amount": 5000,
  "type": "expense",
  "category": "Transport",
  "date": "2026-10-29",
  "paymentMethod": "Mobile Money",
  "notes": "Morning transport"
}
```

### Budgets
- `GET /api/budgets?month=YYYY-MM` — list budgets with spending totals.
- `POST /api/budgets` — create a budget.
- `PUT /api/budgets/:id` — update a budget.
- `DELETE /api/budgets/:id` — delete a budget.

Example JSON for `POST /api/budgets`:
```json
{ "category": "Food", "limit": 150000, "month": "2026-10" }
```

### Summary and health
- `GET /api/summary?month=YYYY-MM` — monthly totals.
- `GET /api/health` — server/database connection status.

## Database design

**Transactions** stores title, amount, type (`income` or `expense`), category, date, payment method, notes and timestamps. Amount must be greater than zero.

**Budgets** stores category, monthly limit and month (`YYYY-MM`). A unique index prevents two budgets for the same category in the same month.

## Suggested tests
1. Add an expense and check that it appears in the table and the expense total changes.
2. Add income and confirm the balance is recalculated.
3. Edit a transaction and confirm the changes persist after refreshing the page.
4. Delete a transaction and confirm it disappears.
5. Add a budget for Food, record Food expenses, and confirm the progress bar updates.
6. Try creating a second budget for the same category and month; the app should show a validation message.
7. Change the month filter and confirm monthly results change.

## Notes for academic submission
- Read through the code and be ready to explain the model schemas, REST routes, CRUD operations and database connection.
- Add your name, registration number, course/unit and lecturer details to any separate report required by your institution.
- This is a classroom/demo application and does not include user login or production-grade access controls. Do not enter confidential financial information.
